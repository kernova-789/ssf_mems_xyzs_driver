#!/usr/bin/env python3
"""按单次启动的内核时间合并有重叠的快照/跟随日志，逐行去重输出。"""
import re
import sys
from pathlib import Path
rows = set()
for name in sys.argv[1:]:
    for line in Path(name).read_text().splitlines():
        match = re.match(r"\[\s*(\d+\.\d+)\]", line)
        if match:
            rows.add((float(match[1]), line))
for _, line in sorted(rows):
    print(line)
