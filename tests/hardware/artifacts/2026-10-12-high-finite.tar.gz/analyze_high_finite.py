#!/usr/bin/env python3
"""离线检查实验日志；区分配置回显、原始批次和普通读错误，不掩盖重试。"""
import argparse
import json
import re
from pathlib import Path


def crc16(data):
    crc = 0xffff
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0xa001 if crc & 1 else 0)
    return crc


def summarize(text):
    runs = []
    current = None
    for line in text.splitlines():
        match = re.search(r"HF TEST START seconds=(\d+) sampling=(\d+) points=(\d+) baud=(\d+)", line)
        if match:
            current = dict(zip(("planned_seconds", "sampling_index", "points_per_batch", "baud"), map(int, match.groups())))
            current.update(batches=[], feature_ok=0, feature_bad=0, short_ok=0, short_bad=0, finished=False)
            runs.append(current)
            continue
        if current is None:
            continue
        match = re.search(r"HF BATCH (.+)", line)
        if match:
            current["batches"].append({k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", match[1])})
        match = re.search(r"HF f=(\d+) addr=(\d+) qtyval=(\d+) sent=(-?\d+) rx=(\d+) overflow=(\d+) crc=\w+ data=(.*)", line)
        if match:
            fn, addr, qty, sent, size, overflow = map(int, match.groups()[:6])
            data = bytes.fromhex(match[7])
            if fn != 3 or (addr, qty) not in ((0, 29), (101, 1)):
                continue  # 私有触发没有普通应答，不算一次 FC03 失败。
            valid = (sent == 8 and overflow == 0 and size == len(data) == qty * 2 + 5
                     and data[:3] == bytes((1, 3, qty * 2)) and crc16(data) == 0)
            if addr == 101:
                rates = [9600, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 128000, 230400, 256000, 460800, 500000, 512000, 600000, 750000, 921600, 1000000]
                index = rates.index(current["baud"], 1)
                valid = valid and data[3:5] == bytes((0, index))
            current[("feature" if addr == 0 else "short") + ("_ok" if valid else "_bad")] += 1
        match = re.search(r"HF FINISH (.+)", line)
        if match:
            finish = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", match[1])}
            current["finish"] = finish
            current["finished"] = True
            current["counters_match"] = all(current[k] == finish[k] for k in ("feature_ok", "feature_bad", "short_ok", "short_bad"))
            current["batch_count_match"] = len(current["batches"]) == finish["cycles"]
            current = None
    for run in runs:
        batches = run.pop("batches")
        run["batch_count"] = len(batches)
        run["raw_packets"] = sum(b["packets"] for b in batches)
        run["valid_xyz_records"] = run["raw_packets"] * 64
        run["raw_bad_candidates"] = sum(b["bad"] for b in batches)
        run["sequence_gaps"] = sum(b["gaps"] for b in batches)
        run["incomplete_batches"] = [b for b in batches if b["complete"] != 1
                                     or b["packets"] * 64 != run["points_per_batch"]
                                     or any(b[k] != 0 for k in ("bad", "gaps", "partial", "ignored"))]
        finish = run.get("finish", {})
        run["pass_independent"] = bool(run["finished"] and finish.get("elapsed_ms", 0) >= run["planned_seconds"] * 1000
                                       and run.get("counters_match") and run.get("batch_count_match")
                                       and len(batches) > 0 and not run["incomplete_batches"]
                                       and run["feature_ok"] > 0 and run["feature_bad"] == 0 and run["short_bad"] == 0)
        run["kernel_verdict_match"] = run["finished"] and int(run["pass_independent"]) == finish.get("passed")
    return runs


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path)
    args = parser.parse_args()
    print(json.dumps(summarize(args.log.read_text()), ensure_ascii=False, indent=2))
