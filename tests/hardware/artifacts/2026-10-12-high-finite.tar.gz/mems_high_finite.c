// SPDX-License-Identifier: GPL-2.0-only
/* 有界硬件实验，不链接正式驱动；普通通信与定长数据均保持 1 Mbaud。 */
#include <linux/delay.h>
#include <linux/jiffies.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/serdev.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/workqueue.h>

static bool switch_high; /* 显式允许一次 40102=17、40110=1；不自动重复保存。 */
module_param(switch_high, bool, 0444);
static bool switch_low; /* 必要时仅一次从已核实的 1 Mbaud 改到 115200，非恢复默认。 */
module_param(switch_low, bool, 0444);
static bool switch_rate; /* 分档试验：核实旧档后仅执行一次保存/重启。 */
module_param(switch_rate, bool, 0444);
static unsigned int from_baud = 1000000; /* 仅切速动作使用的已核实当前速率。 */
module_param(from_baud, uint, 0444);
static unsigned int test_baud = 1000000; /* 对照只接受 1 Mbaud 或 115200。 */
module_param(test_baud, uint, 0444);
static unsigned int seconds = 1800; /* 本轮交替采集的计划时长，不包括配置阶段。 */
module_param(seconds, uint, 0444);
static bool configure_rate; /* 可选地把采样索引改为 6，仅配置一次，固件自动保存。 */
module_param(configure_rate, bool, 0444);
static bool snapshot_only; /* 仅三轮读取32个配置寄存器，不启动采集或写参数。 */
module_param(snapshot_only, bool, 0444);

/* 与固定固件枚举对应，不允许猜测不存在的串口速率。 */
static int baud_index(unsigned int baud)
{
  static const unsigned int rates[] = {
    9600, 2400, 4800, 9600, 19200, 38400, 57600, 115200,
    128000, 230400, 256000, 460800, 500000, 512000, 600000,
    750000, 921600, 1000000
  };
  unsigned int i;
  for (i = 1; i < ARRAY_SIZE(rates); i++)
    if (rates[i] == baud)
      return i;
  return -EINVAL;
}

/* 私有包与普通应答互斥接收，测试状态仅由单个工作线程推进。 */
struct high_lab {
  struct serdev_device *serial; /* 本次独占的 serdev 总线。 */
  struct work_struct work; /* probe 返回后执行配置或测试。 */
  spinlock_t lock; /* 保护回调中的字节与私有包统计。 */
  bool stopping; /* 卸载只停止下一批，当前批次仍有界等待完成。 */
  bool finite; /* true 按私有 XYZ 包解析，否则收集 Modbus 字节。 */
  u8 bytes[512]; /* 单次普通请求的原始接收内容。 */
  unsigned int used; /* 普通接收数组的有效字节数。 */
  unsigned int overflow; /* 普通接收溢出字节数，不能忽略。 */
  u8 packet[392]; /* 当前正在拼装的私有包。 */
  unsigned int partial; /* 私有候选包已收字节数。 */
  unsigned int packets; /* 本批 CRC 正确的完整包数。 */
  unsigned int bad; /* 本批损坏的私有候选包数。 */
  unsigned int gaps; /* 本批包号断裂次数。 */
  unsigned int ignored; /* 私有模式中未属于候选包的字节数。 */
  u32 next; /* 本批预期的下一个包号，从零开始。 */
};

/* 标准 Modbus RTU CRC；包含线上 CRC 的完整帧余数应为零。 */
static u16 crc16(const u8 *buf, unsigned int len)
{
  u16 crc = 0xffff;
  unsigned int i, bit;
  for (i = 0; i < len; i++) {
    crc ^= buf[i];
    for (bit = 0; bit < 8; bit++)
      crc = (crc & 1U) != 0 ? (crc >> 1) ^ 0xa001 : crc >> 1;
  }
  return crc;
}

/* 接收锁内拼包；计入坏包和丢失头部，不静默跳过异常。 */
static void private_byte(struct high_lab *lab, u8 byte)
{
  u32 sequence;
  if (lab->partial == 0 && byte != 0x15) {
    lab->ignored++;
    return;
  }
  lab->packet[lab->partial++] = byte;
  if (lab->partial != sizeof(lab->packet))
    return;
  if (lab->packet[391] == 0x17 && crc16(lab->packet, 391) == 0) {
    sequence = (u32)lab->packet[1] << 24 | (u32)lab->packet[2] << 16 |
               (u32)lab->packet[3] << 8 | lab->packet[4];
    if (sequence != lab->next)
      lab->gaps++;
    lab->next = sequence + 1;
    lab->packets++;
    lab->partial = 0;
    return;
  }
  lab->bad++;
  do {
    lab->partial--;
    memmove(lab->packet, lab->packet + 1, lab->partial);
  } while (lab->partial != 0 && lab->packet[0] != 0x15);
}

/* 回调只保存/校验接收数据，不在中断交付路径打印或发送命令。 */
static int receive(struct serdev_device *serial, const unsigned char *buf,
                   size_t count)
{
  struct high_lab *lab = serdev_device_get_drvdata(serial);
  unsigned long flags;
  size_t i, size;
  spin_lock_irqsave(&lab->lock, flags);
  if (lab->finite == true) {
    for (i = 0; i < count; i++)
      private_byte(lab, buf[i]);
  } else {
    size = min(count, sizeof(lab->bytes) - lab->used);
    memcpy(lab->bytes + lab->used, buf, size);
    lab->used += size;
    lab->overflow += count - size;
  }
  spin_unlock_irqrestore(&lab->lock, flags);
  return count;
}

/* 唤醒 serdev 的同步发送等待者。 */
static void wakeup(struct serdev_device *serial)
{
  serdev_device_write_wakeup(serial);
}

static const struct serdev_device_ops ops = {
  .receive_buf = receive,
  .write_wakeup = wakeup,
};

/* 一次 RTU 请求，完整记录应答；写命令在本函数内绝不重发。 */
static unsigned int exchange(struct high_lab *lab, u8 fn, u16 addr, u16 value,
                             u8 *out)
{
  u8 frame[8] = {1, fn, addr >> 8, addr, value >> 8, value};
  u16 crc = crc16(frame, 6);
  unsigned long flags;
  unsigned int size, overflow;
  int sent;
  frame[6] = crc;
  frame[7] = crc >> 8;
  spin_lock_irqsave(&lab->lock, flags);
  lab->used = lab->overflow = 0;
  spin_unlock_irqrestore(&lab->lock, flags);
  sent = serdev_device_write(lab->serial, frame, sizeof(frame), HZ);
  serdev_device_wait_until_sent(lab->serial, HZ);
  msleep(200);
  spin_lock_irqsave(&lab->lock, flags);
  size = lab->used;
  overflow = lab->overflow;
  memcpy(out, lab->bytes, size);
  spin_unlock_irqrestore(&lab->lock, flags);
  dev_info(&lab->serial->dev,
           "HF f=%u addr=%u qtyval=%u sent=%d rx=%u overflow=%u crc=%04x data=%*ph\n",
           fn, addr, value, sent, size, overflow, crc16(out, size),
           min(size, 80U), out);
  return sent == sizeof(frame) && overflow == 0 ? size : 0;
}

/* 严格校验普通读响应的地址、功能码、长度及 CRC。 */
static bool valid_read(const u8 *buf, unsigned int size, u16 count)
{
  return size == count * 2U + 5U && buf[0] == 1 && buf[1] == 3 &&
         buf[2] == count * 2U && crc16(buf, size) == 0;
}

/* 配置守卫允许有界只读重试，异常帧仍逐次留证；不重复配置写入。 */
static bool checked_read(struct high_lab *lab, u16 addr, u16 count, u8 *buf)
{
  unsigned int i, size;
  for (i = 0; i < 20; i++) {
    size = exchange(lab, 3, addr, count, buf);
    if (valid_read(buf, size, count) == true)
      return true;
    msleep(100);
  }
  return false;
}

/* 切换普通速率仅执行一次；即使保存回显丢失，也只读寻找新速率。 */
static void switch_once(struct high_lab *lab)
{
  u8 buf[512];
  unsigned int size;
  u8 old_index = switch_low == true ? 17 : 3;
  u8 new_index = switch_low == true ? 7 : 17;
  unsigned int old_baud = switch_low == true ? 1000000 : 9600;
  unsigned int new_baud = switch_low == true ? 115200 : 1000000;
  if (switch_rate == true) {
    old_baud = from_baud;
    new_baud = test_baud;
    old_index = baud_index(old_baud);
    new_index = baud_index(new_baud);
  }
  if (checked_read(lab, 100, 5, buf) == false ||
      memcmp(buf + 3, (u8[]){0,1,0,old_index,0,0,0,255,0,1}, 10) != 0) {
    dev_err(&lab->serial->dev, "HF switch aborted: initial %u configuration unverified\n", old_baud);
    return;
  }
  size = exchange(lab, 6, 101, new_index, buf);
  if (size != 8 || crc16(buf, size) != 0 ||
      memcmp(buf, (u8[]){1,6,0,101,0,new_index}, 6) != 0) {
    /* 写回显损坏只能通过只读确认暂存值，不能重发写入。 */
    if (checked_read(lab, 100, 5, buf) == false ||
        memcmp(buf + 3, (u8[]){0,1,0,new_index,0,0,0,255,0,1}, 10) != 0) {
      dev_err(&lab->serial->dev, "HF staging unconfirmed; no save or write retry\n");
      return;
    }
  }
  dev_warn(&lab->serial->dev, "HF ONE 40110 save/reboot at %u; NO write retry\n", old_baud);
  exchange(lab, 6, 109, 1, buf);
  msleep(8000);
  if (serdev_device_set_baudrate(lab->serial, new_baud) != new_baud ||
      checked_read(lab, 100, 5, buf) == false ||
      memcmp(buf + 3, (u8[]){0,1,0,new_index,0,0,0,255,0,1}, 10) != 0) {
    dev_err(&lab->serial->dev, "HF switch NOT verified; preserve state, no repeat save\n");
    return;
  }
  dev_info(&lab->serial->dev, "HF SWITCH VERIFIED: ordinary baud=%u, address=1, parity=0\n", new_baud);
}

/* 定长1024 XYZ与完整29寄存器特征交替；首包/完成超时即结束，不自动复位。 */
static void run_test(struct high_lab *lab)
{
  u8 buf[512];
  unsigned long flags, started, until, deadline;
  unsigned int size, cycle = 0, feature_ok = 0, feature_bad = 0;
  unsigned int short_ok = 0, short_bad = 0, consecutive_bad = 0, i;
  bool complete = false;
  u16 rate;
  u8 expected_index = baud_index(test_baud);

  if (checked_read(lab, 100, 5, buf) == false ||
      memcmp(buf + 3, (u8[]){0,1,0,expected_index,0,0,0,255,0,1}, 10) != 0 ||
      checked_read(lab, 51, 2, buf) == false || buf[5] != 0 || buf[6] != 0) {
    dev_err(&lab->serial->dev, "HF TEST ABORTED: initial configuration unverified\n");
    return;
  }
  rate = buf[3] * 256U + buf[4];
  if (configure_rate == true && rate != 6) {
    exchange(lab, 6, 51, 6, buf);
    msleep(4000);
    if (checked_read(lab, 51, 2, buf) == false ||
        memcmp(buf + 3, (u8[]){0,6,0,0}, 4) != 0) {
      dev_err(&lab->serial->dev, "HF TEST ABORTED: sampling configuration unverified\n");
      return;
    }
    rate = 6;
  }
  if (rate > 8 || checked_read(lab, 60, 2, buf) == false ||
      memcmp(buf + 3, (u8[]){0,0,0,0}, 4) != 0) {
    dev_err(&lab->serial->dev, "HF TEST ABORTED: custom length must be zero (1024 XYZ)\n");
    return;
  }
  started = jiffies;
  until = started + msecs_to_jiffies(seconds * 1000U);
  dev_info(&lab->serial->dev, "HF TEST START seconds=%u sampling=%u points=1024 baud=%u\n", seconds, rate, test_baud);
  while (time_before(jiffies, until) == true && READ_ONCE(lab->stopping) == false) {
    spin_lock_irqsave(&lab->lock, flags);
    lab->packets = lab->partial = lab->bad = lab->gaps = lab->ignored = lab->next = 0;
    lab->finite = true;
    spin_unlock_irqrestore(&lab->lock, flags);
    exchange(lab, 3, 59, 1, buf);
    deadline = jiffies + msecs_to_jiffies(22000);
    while (READ_ONCE(lab->packets) < 16 && time_before(jiffies, deadline) == true)
      msleep(20);
    msleep(300);
    spin_lock_irqsave(&lab->lock, flags);
    lab->finite = false;
    complete = lab->packets == 16 && lab->bad == 0 && lab->gaps == 0 &&
               lab->partial == 0 && lab->ignored == 0;
    spin_unlock_irqrestore(&lab->lock, flags);
    cycle++;
    dev_info(&lab->serial->dev,
             "HF BATCH cycle=%u elapsed_ms=%u packets=%u bad=%u gaps=%u partial=%u ignored=%u complete=%u\n",
             cycle, jiffies_to_msecs(jiffies - started), lab->packets, lab->bad,
             lab->gaps, lab->partial, lab->ignored, complete);
    if (complete == false) {
      dev_err(&lab->serial->dev, "HF FAILED batch; no stop/reset/save, preserving state\n");
      break;
    }
    size = exchange(lab, 3, 101, 1, buf);
    if (valid_read(buf, size, 1) == true && buf[3] == 0 && buf[4] == expected_index)
      short_ok++;
    else
      short_bad++;
    for (i = 0; i < 5; i++) {
      size = exchange(lab, 3, 0, 29, buf);
      if (valid_read(buf, size, 29) == true) {
        feature_ok++;
        consecutive_bad = 0;
      } else {
        feature_bad++;
        consecutive_bad++;
      }
      if (consecutive_bad >= 5 || READ_ONCE(lab->stopping) == true)
        break;
      msleep(800);
    }
    dev_info(&lab->serial->dev,
             "HF PROGRESS cycle=%u elapsed_ms=%u feature_ok=%u feature_bad=%u short_ok=%u short_bad=%u\n",
             cycle, jiffies_to_msecs(jiffies - started), feature_ok, feature_bad,
             short_ok, short_bad);
    if (consecutive_bad >= 5) {
      dev_err(&lab->serial->dev, "HF FAILED five consecutive full-feature reads; no reset\n");
      break;
    }
  }
  dev_info(&lab->serial->dev,
           "HF FINISH planned=%u elapsed_ms=%u cycles=%u feature_ok=%u feature_bad=%u short_ok=%u short_bad=%u passed=%u\n",
           seconds, jiffies_to_msecs(jiffies - started), cycle, feature_ok, feature_bad,
           short_ok, short_bad, time_after_eq(jiffies, until) == true &&
           complete == true && feature_ok != 0 && feature_bad == 0 && short_bad == 0);
}

/* 普通只读范围避开私有起始地址，逐次校验，不重试掩盖退出时的异常。 */
static void read_snapshot(struct high_lab *lab)
{
  static const u16 ranges[][2] = {{49,4}, {52,7}, {60,11}, {100,10}, {120,1}};
  u8 buf[512];
  unsigned int round, range, size, invalid = 0;
  for (round = 0; round < 3; round++) {
    for (range = 0; range < ARRAY_SIZE(ranges); range++) {
      size = exchange(lab, 3, ranges[range][0], ranges[range][1], buf);
      if (valid_read(buf, size, ranges[range][1]) == false)
        invalid++;
      /* 保留旧只读快照解码器格式，原始 HF 日志仍保留。 */
      dev_info(&lab->serial->dev,
               "lab f=3 addr=%u value=%u sent=8 rx=%u crc=%04x data=%*ph\n",
               ranges[range][0], ranges[range][1], size, crc16(buf, size),
               min(size, 80U), buf);
      msleep(100);
    }
  }
  dev_info(&lab->serial->dev, "BASELINE READONLY finished; no register writes\n");
  dev_info(&lab->serial->dev, "HF SNAPSHOT invalid=%u baud=%u\n", invalid, test_baud);
}

/* probe 不发 Modbus，所有配置与测试都在本工作线程进行。 */
static void work(struct work_struct *item)
{
  struct high_lab *lab = container_of(item, struct high_lab, work);
  msleep(500);
  if (snapshot_only == true)
    read_snapshot(lab);
  else if (switch_high == true || switch_low == true || switch_rate == true)
    switch_once(lab);
  else
    run_test(lab);
  dev_info(&lab->serial->dev, "HF WORK FINISHED; no automatic parameter restoration\n");
}

/* 只打开主机串口并配置 8N1，实际速率必须与请求一致。 */
static int probe(struct serdev_device *serial)
{
  struct high_lab *lab;
  int ret;
  unsigned int baud = switch_high == true ? 9600 : switch_low == true ? 1000000 : test_baud;
  if (switch_rate == true)
    baud = from_baud;
  if (seconds == 0 || seconds > 3600 || (switch_high == true && switch_low == true) ||
      (switch_rate == true && (switch_high == true || switch_low == true || from_baud == test_baud)) ||
      (snapshot_only == true && (switch_high == true || switch_low == true || switch_rate == true || configure_rate == true)) ||
      baud_index(test_baud) < 0 || baud_index(from_baud) < 0)
    return -EINVAL;
  lab = devm_kzalloc(&serial->dev, sizeof(*lab), GFP_KERNEL);
  if (lab == NULL)
    return -ENOMEM;
  lab->serial = serial;
  spin_lock_init(&lab->lock);
  INIT_WORK(&lab->work, work);
  serdev_device_set_drvdata(serial, lab);
  serdev_device_set_client_ops(serial, &ops);
  ret = serdev_device_open(serial);
  if (ret != 0)
    return ret;
  serdev_device_set_flow_control(serial, false);
  ret = serdev_device_set_parity(serial, SERDEV_PARITY_NONE);
  if (ret != 0 || serdev_device_set_baudrate(serial, baud) != baud) {
    serdev_device_close(serial);
    return ret != 0 ? ret : -EIO;
  }
  schedule_work(&lab->work);
  return 0;
}

/* 当前批次有界退出后关闭主机端口，不修改传感器参数。 */
static void remove(struct serdev_device *serial)
{
  struct high_lab *lab = serdev_device_get_drvdata(serial);
  WRITE_ONCE(lab->stopping, true);
  cancel_work_sync(&lab->work);
  serdev_device_close(serial);
}

static const struct of_device_id match[] = {
  {.compatible = "sange-cbm,ssf-mems-xyzs"}, {}
};
static struct serdev_device_driver high_driver = {
  .driver = {.name = "mems_high_finite", .of_match_table = match},
  .probe = probe, .remove = remove,
};
module_serdev_device_driver(high_driver);
MODULE_LICENSE("GPL");
