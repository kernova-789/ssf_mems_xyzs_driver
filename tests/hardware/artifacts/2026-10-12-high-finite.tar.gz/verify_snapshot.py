#!/usr/bin/env python3
"""对最终15次只读响应重算CRC，并核实32寄存器只保留预期的两项差异。"""
import json
import re
import sys
from pathlib import Path
from analyze_high_finite import crc16

def snapshot(path):
    lines = [line for line in Path(path).read_text().splitlines() if "lab f=3 addr=" in line][-15:]
    assert len(lines) == 15, "snapshot must contain 15 reads"
    registers, seen = {}, {}
    for line in lines:
        match = re.search(r"lab f=3 addr=(\d+) value=(\d+) sent=8 rx=(\d+) crc=\w+ data=(.*)", line)
        assert match, line
        address, count, size = map(int, match.groups()[:3])
        data = bytes.fromhex(match[4])
        assert size == len(data) == 2*count+5 and data[:3] == bytes((1,3,2*count)) and crc16(data) == 0, line
        for offset in range(count):
            reg = 40001 + address + offset
            value = int.from_bytes(data[3+2*offset:5+2*offset], "big")
            assert reg not in registers or registers[reg] == value
            registers[reg] = value
            seen[reg] = seen.get(reg, 0) + 1
    assert len(registers) == 32 and min(seen.values()) >= 3
    return registers

initial, final = map(snapshot, sys.argv[1:3])
differences = {reg: [value, final[reg]] for reg, value in initial.items() if value != final[reg]}
assert differences == {40052: [0,6], 40102: [3,8]}, differences
assert final[40101] == 1 and final[40103] == 0 and final[40059] == 0 and final[40121] == 5100
print(json.dumps({"registers_checked": 32, "expected_changes_verified": True, "differences": differences, "final": final}, indent=2))
