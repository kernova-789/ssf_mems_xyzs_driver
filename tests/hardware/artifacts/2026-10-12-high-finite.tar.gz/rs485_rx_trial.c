// SPDX-License-Identifier: GPL-2.0-only
/* 独立主机侧对照：保持 DE 极性/延时，仅关闭收发切换时的 RX 禁用/清空。 */
#include <linux/module.h>
#include <linux/serial_8250.h>
#include <linux/tty.h>
extern struct uart_8250_port *serial8250_get_port(int line);

static struct uart_8250_port *trial_port; /* 经 MMIO 地址确认的本次 ttyS4。 */
static struct serial_rs485 original; /* 卸载恢复主机原始配置，不写传感器。 */

/* 复用目标 UART 的配置回调和内核原有的 mutex→spinlock 加锁顺序。 */
static int apply_config(struct serial_rs485 *config, bool require_closed)
{
  struct uart_port *port = &trial_port->port;
  struct tty_port *tty_port = &port->state->port;
  unsigned long flags;
  int ret;
  mutex_lock(&tty_port->mutex);
  if (require_closed == true && tty_port_initialized(tty_port) == true) {
    mutex_unlock(&tty_port->mutex);
    return -EBUSY;
  }
  spin_lock_irqsave(&port->lock, flags);
  ret = port->rs485_config(port, config);
  spin_unlock_irqrestore(&port->lock, flags);
  mutex_unlock(&tty_port->mutex);
  return ret;
}

/* 只在采集模块已卸载、串口已关闭时安装对照配置。 */
static int __init trial_init(void)
{
  struct serial_rs485 trial;
  int ret;
  trial_port = serial8250_get_port(4);
  if (trial_port == NULL || trial_port->port.mapbase != 0xfeb70000 ||
      trial_port->port.state == NULL || trial_port->port.rs485_config == NULL)
    return -ENODEV;
  original = trial_port->port.rs485;
  if ((original.flags & SER_RS485_ENABLED) == 0)
    return -EINVAL;
  trial = original;
  trial.flags |= SER_RS485_RX_DURING_TX;
  ret = apply_config(&trial, true);
  if (ret != 0)
    return ret;
  pr_info("HF RX TRIAL flags=%x -> %x; DE polarity/delays unchanged; no sensor writes\n",
          original.flags, trial_port->port.rs485.flags);
  return 0;
}

/* 测试采集模块先卸载，再卸载本模块，恢复主机的原始 RS485 设置。 */
static void __exit trial_exit(void)
{
  int ret = apply_config(&original, false);
  pr_info("HF RX TRIAL RESTORE ret=%d flags=%x\n", ret, trial_port->port.rs485.flags);
}
module_init(trial_init);
module_exit(trial_exit);
MODULE_LICENSE("GPL");
