// SPDX-License-Identifier: GPL-2.0-only
/* 仅通过目标内核导出的接口读取 ttyS4 方向配置；不修改端口或 GPIO。 */
#include <linux/module.h>
#include <linux/serial_8250.h>
/* 目标内核导出但仅在 8250 内部头声明；此处使用其原型，不访问符号地址。 */
extern struct uart_8250_port *serial8250_get_port(int line);
static int __init snapshot_init(void)
{
  struct uart_8250_port *up = serial8250_get_port(4);
  unsigned long flags;
  if (up == NULL || up->port.mapbase != 0xfeb70000)
    return -ENODEV;
  spin_lock_irqsave(&up->port.lock, flags);
  pr_info("HF RS485 SNAPSHOT line=%u map=%llx flags=%x before_ms=%u after_ms=%u frame_ns=%u caps=%x em485=%u rx=%u frame_errors=%u breaks=%u overruns=%u\n",
          up->port.line, (unsigned long long)up->port.mapbase,
          up->port.rs485.flags, up->port.rs485.delay_rts_before_send,
          up->port.rs485.delay_rts_after_send, up->port.frame_time,
          up->capabilities, up->em485 != NULL, up->port.icount.rx,
          up->port.icount.frame, up->port.icount.brk, up->port.icount.overrun);
  spin_unlock_irqrestore(&up->port.lock, flags);
  return 0;
}
static void __exit snapshot_exit(void) {}
module_init(snapshot_init);
module_exit(snapshot_exit);
MODULE_LICENSE("GPL");
