// SPDX-License-Identifier: GPL-2.0-only
/* 有界诊断：临时请求最低 CPU 唤醒延迟，检查软件 RS485 换向是否受空闲影响。 */
#include <linux/module.h>
#include <linux/pm_qos.h>
static struct pm_qos_request latency; /* 卸载移除此请求，不修改永久电源策略。 */
static int __init latency_init(void)
{
  cpu_latency_qos_add_request(&latency, 0);
  pr_info("HF LATENCY TRIAL enabled CPU latency QoS=0 us; no sensor writes\n");
  return 0;
}
static void __exit latency_exit(void)
{
  cpu_latency_qos_remove_request(&latency);
  pr_info("HF LATENCY TRIAL removed\n");
}
module_init(latency_init);
module_exit(latency_exit);
MODULE_LICENSE("GPL");
