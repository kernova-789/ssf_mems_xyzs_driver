"""检查判定器不能把提前停止、损坏应答或计数不符判成成功。"""
import unittest
from analyze_high_finite import crc16, summarize


def response(addr, qty, payload):
    data = bytes((1, 3, qty * 2)) + payload
    crc = crc16(data)
    data += bytes((crc & 255, crc >> 8))
    return f"HF f=3 addr={addr} qtyval={qty} sent=8 rx={len(data)} overflow=0 crc=0000 data={data.hex(' ')}"


def fixture(elapsed=1000, feature_bad=0, packets=16):
    feature = response(0, 29, bytes(58))
    if feature_bad:
        feature = feature.replace("data=01", "data=80")
    return "\n".join((
        "HF TEST START seconds=1 sampling=6 points=1024 baud=1000000",
        f"HF BATCH cycle=1 elapsed_ms=500 packets={packets} bad=0 gaps=0 partial=0 ignored=0 complete={int(packets == 16)}",
        response(101, 1, b"\x00\x11"), feature,
        f"HF FINISH planned=1 elapsed_ms={elapsed} cycles=1 feature_ok={1-feature_bad} feature_bad={feature_bad} short_ok=1 short_bad=0 passed={int(elapsed >= 1000 and feature_bad == 0 and packets == 16)}"))


class AnalyzerTests(unittest.TestCase):
    def test_valid(self):
        self.assertTrue(summarize(fixture())[0]["pass_independent"])

    def test_early_stop(self):
        self.assertFalse(summarize(fixture(elapsed=999))[0]["pass_independent"])

    def test_corrupted_crc(self):
        run = summarize(fixture(feature_bad=1))[0]
        self.assertEqual(run["feature_bad"], 1)
        self.assertFalse(run["pass_independent"])

    def test_incomplete_batch(self):
        self.assertFalse(summarize(fixture(packets=15))[0]["pass_independent"])

    def test_misreported_counters(self):
        text = fixture().replace("cycles=1 feature_ok=1", "cycles=1 feature_ok=9")
        self.assertFalse(summarize(text)[0]["pass_independent"])

    def test_missing_finish(self):
        text = fixture().split("HF FINISH")[0]
        self.assertFalse(summarize(text)[0]["pass_independent"])

    def test_misreported_complete(self):
        text = fixture().replace("packets=16 bad=0", "packets=15 bad=0")
        self.assertFalse(summarize(text)[0]["pass_independent"])

    def test_misreported_raw_crc(self):
        text = fixture().replace("packets=16 bad=0", "packets=16 bad=1")
        self.assertFalse(summarize(text)[0]["pass_independent"])

    def test_128000_index(self):
        text = fixture().replace("baud=1000000", "baud=128000")
        text = text.replace(response(101, 1, b"\x00\x11"), response(101, 1, b"\x00\x08"))
        self.assertTrue(summarize(text)[0]["pass_independent"])


if __name__ == "__main__":
    unittest.main()
