import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from iio_devices import find_pair

root = Path(__file__).resolve().parent
result = {'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
          'kernel': subprocess.check_output(['uname', '-a'], text=True).strip(),
          'boottime': time.clock_gettime(time.CLOCK_BOOTTIME), 'instances': {}}
for port, instance in [('RS485-1', 'serial0-0'), ('RS485-2', 'serial1-0')]:
    pair = find_pair(instance)
    row = result['instances'][port] = {'serdev': instance, 'devices': {}}
    for role, path in pair.items():
        attrs = ['buffer/enable', 'sensor_online', 'sensor_baudrate',
                 'sensor_sampling_rate_index', 'sensor_sampling_frequency',
                 'sensor_acquisition_mode', 'sensor_poll_mode',
                 'sensor_poll_fixed_interval_ms', 'sensor_firmware_version']
        if role.endswith('_raw'):
            attrs = ['buffer/enable', 'raw_crc_errors', 'raw_sequence_gaps',
                     'raw_buffer_drops', 'raw_drain_crc_errors',
                     'raw_drain_sequence_gaps', 'raw_ignored_bytes']
        values = row['devices'][role] = {'path': str(path), 'resolved': str(path.resolve())}
        for attr in attrs:
            try:
                values[attr] = (path / attr).read_text().strip()
            except OSError as error:
                values[attr] = {'error': repr(error), 'errno': error.errno}
    of_path = Path('/sys/bus/serial/devices') / instance / 'of_node'
    row['of_node'] = str(of_path.resolve())
    row['compatible'] = (of_path / 'compatible').read_bytes().rstrip(b'\0').decode()
for name, command in [('kernel-final.log', ['dmesg']),
                      ('uart-final.log', ['cat', '/proc/tty/driver/serial']),
                      ('processes-final.log', ['ps', '-eo', 'pid,args'])]:
    (root / name).write_text(subprocess.check_output(command, text=True))
dtbo = Path('/boot/dtb/overlay/rk3588-lubancat-5io-rs485-2-overlay.dtbo')
result['deployed_dtbo_sha256'] = hashlib.sha256(dtbo.read_bytes()).hexdigest()
(root / 'final-state.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
