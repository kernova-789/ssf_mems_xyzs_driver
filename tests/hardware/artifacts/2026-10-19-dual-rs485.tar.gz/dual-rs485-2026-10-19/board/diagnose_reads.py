"""Record every planned configuration read, including errors; never retry a failed read."""
from concurrent.futures import ThreadPoolExecutor
import errno
import json
from pathlib import Path
import subprocess
import sys
import time

from iio_devices import find_pair

base = Path(sys.argv[1])
base.mkdir()
pairs = {port: find_pair(instance) for port, instance in
         [('RS485-1', 'serial0-0'), ('RS485-2', 'serial1-0')]}
features = {port: pair['ssf_mems_xyzs'] for port, pair in pairs.items()}
saved = {port: (device / 'sensor_acquisition_mode').read_text().strip()
         for port, device in features.items()}
keys = ('sensor_baudrate', 'sensor_sampling_rate_index', 'sensor_sampling_frequency',
        'sensor_sampling_length_index', 'sensor_parameter_switch',
        'sensor_feature_enable', 'sensor_firmware_version')
result = {'phases': {}, 'initial_modes': saved}


def collect(port, phase):
    feature = features[port]
    raw = pairs[port]['ssf_mems_xyzs_raw']
    rows = []
    with (base / (phase + '-' + port + '.jsonl')).open('w') as log:
        for round_index in range(10):
            for key in keys:
                started = time.monotonic()
                row = dict(round=round_index, attribute=key,
                           boottime=time.clock_gettime(time.CLOCK_BOOTTIME),
                           mode_before=(raw / 'raw_link_mode').read_text().strip())
                try:
                    row['value'] = (feature / key).read_text().strip()
                    row['errno'] = 0
                except OSError as error:
                    row['errno'] = error.errno
                    row['error'] = str(error)
                row['elapsed_ms'] = round((time.monotonic() - started) * 1000, 3)
                row['mode_after'] = (raw / 'raw_link_mode').read_text().strip()
                rows.append(row)
                log.write(json.dumps(row) + '\n')
                log.flush()
                time.sleep(0.02)
    errors = [row for row in rows if row['errno']]
    return dict(reads=len(rows), errors=errors,
                max_elapsed_ms=max(row['elapsed_ms'] for row in rows),
                final_online=(feature / 'sensor_online').read_text().strip())


try:
    for phase in ('alternating', 'feature'):
        for feature in features.values():
            (feature / 'sensor_acquisition_mode').write_text(phase)
        (base / (phase + '-kernel-before.log')).write_text(subprocess.check_output(['dmesg'], text=True))
        (base / (phase + '-uart-before.log')).write_text(Path('/proc/tty/driver/serial').read_text())
        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = {port: executor.submit(collect, port, phase) for port in features}
            result['phases'][phase] = {port: future.result() for port, future in futures.items()}
        (base / (phase + '-kernel-after.log')).write_text(subprocess.check_output(['dmesg'], text=True))
        (base / (phase + '-uart-after.log')).write_text(Path('/proc/tty/driver/serial').read_text())
        print(json.dumps({phase: result['phases'][phase]}), flush=True)
finally:
    for port, feature in features.items():
        (feature / 'sensor_acquisition_mode').write_text(saved[port])
    result['restored_modes'] = {port: (device / 'sensor_acquisition_mode').read_text().strip()
                                for port, device in features.items()}
    (base / 'read_diagnostic_summary.json').write_text(json.dumps(result, indent=2))
