import json
from pathlib import Path
import subprocess
import sys

base = Path(sys.argv[1])
results = []
for case in ('api', 'invalid-buffer', 'layouts'):
    running = []
    for port, instance in [('RS485-1', 'serial0-0'), ('RS485-2', 'serial1-0')]:
        output = base / 'functional' / port / case
        output.mkdir(parents=True)
        log = (output / 'console.log').open('w')
        child = subprocess.Popen([sys.executable, str(base / 'board_driver_functional.py'),
                                  str(output), case, '--serdev', instance],
                                 stdout=log, stderr=subprocess.STDOUT)
        running.append((port, instance, child, log))
    for port, instance, child, log in running:
        try:
            code = child.wait(timeout=240)
        finally:
            if child.poll() is None:
                child.kill()
                child.wait()
            log.close()
        row = dict(port=port, serdev=instance, case=case, exit=code)
        results.append(row)
        print(json.dumps(row), flush=True)
    (base / 'functional_summary.json').write_text(json.dumps(results, indent=2))
    if any(row['exit'] for row in results):
        raise SystemExit(1)
