#!/usr/bin/env python3
"""离线逐记录核对目标 ARM64 的全通道 IIO 文件；不接触硬件。"""
import argparse
import json
from pathlib import Path
import struct


def analyze_raw(blob):
    """按 24 字节布局检查每批 0..15/0..63、填充、时间戳和完整批数。"""
    if len(blob) % 24 != 0:
        raise ValueError('raw.bin has a partial IIO record')
    previous = None
    errors = 0
    complete = 0
    records = 0
    for offset in range(0, len(blob), 24):
        _, _, _, sequence, index, stamp = struct.unpack_from('<hhh2xIH2xq', blob, offset)
        pair = (sequence, index)
        expected = (0, 0) if previous is None else (
            (previous[0] + (previous[1] == 63)) % 16, (previous[1] + 1) % 64)
        if (pair != expected or sequence >= 16 or index >= 64 or stamp <= 0 or
                (previous is not None and stamp < previous[2]) or
                blob[offset + 6:offset + 8] != b'\0\0' or
                blob[offset + 14:offset + 16] != b'\0\0'):
            errors += 1
        if pair == (15, 63):
            complete += 1
        records += 1
        previous = (sequence, index, stamp)
    return dict(records=records, complete_batches=complete, errors=errors,
                tail_samples=records % 1024,
                last_position=None if previous is None else list(previous[:2]))


def main():
    """交叉核对二进制记录和在线摘要，返回可供测试脚本使用的退出码。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture', type=Path)
    parser.add_argument('--require-whole-batches', action='store_true')
    args = parser.parse_args()
    summary = json.loads((args.capture / 'capture_summary.json').read_text())
    raw = analyze_raw((args.capture / 'raw.bin').read_bytes())
    feature = (args.capture / 'features.bin').read_bytes()
    failures = []
    if raw['errors'] != 0 or raw['records'] != summary['raw_records']:
        failures.append('raw records/sequence/timestamps/padding mismatch')
    if raw['records'] == 0:
        failures.append('no raw data')
    if args.require_whole_batches and raw['tail_samples'] != 0:
        failures.append('capture ends inside a finite batch')
    if len(feature) % 72 != 0 or len(feature) // 72 != summary['feature_records']:
        failures.append('feature record count/size mismatch')
    else:
        previous = 0
        for offset in range(0, len(feature), 72):
            stamp = struct.unpack_from('<q', feature, offset + 64)[0]
            if stamp <= 0 or stamp < previous:
                failures.append('feature timestamp regression')
                break
            previous = stamp
    print(json.dumps(dict(passed=len(failures) == 0, raw=raw,
                          feature_records=len(feature) // 72, failures=failures), indent=2))
    return 0 if len(failures) == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
