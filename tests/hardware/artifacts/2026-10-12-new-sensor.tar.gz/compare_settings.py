#!/usr/bin/env python3
"""Compare successful read-only sensor snapshots; never sends sensor commands."""
import json
from pathlib import Path
import re
import sys


def snapshot(path):
    """Decode CRC-valid FC03 records from this diagnostic module's kernel log."""
    registers = {}
    seen = {}
    pattern = re.compile(r'lab f=3 addr=(\d+) value=(\d+) sent=8 rx=(\d+) '
                         r'crc=0000 data=([0-9a-f ]+)$')
    lines = Path(path).read_text().splitlines()
    ends = [i for i, line in enumerate(lines) if 'BASELINE READONLY finished' in line]
    if not ends:
        raise ValueError('missing bounded snapshot completion marker')
    lines = [line for line in lines[:ends[-1]] if 'lab f=3 addr=' in line][-15:]
    for line in lines:
        match = pattern.search(line)
        if match is None:
            continue
        address, count, size = map(int, match.group(1, 2, 3))
        data = bytes.fromhex(match[4])
        if size != 5 + count * 2 or len(data) != size or data[:3] != bytes([1, 3, count * 2]):
            continue
        for offset in range(count):
            key = str(40001 + address + offset)
            value = int.from_bytes(data[3 + offset * 2:5 + offset * 2], 'big')
            if key in registers and registers[key] != value:
                raise ValueError('inconsistent snapshot register ' + key)
            registers[key] = value
            seen[key] = seen.get(key, 0) + 1
    if len(registers) != 32 or min(seen.values()) < 3:
        raise ValueError('incomplete snapshot: ' + str(seen))
    return registers


initial = snapshot(sys.argv[1])
if len(sys.argv) == 2:
    print(json.dumps(initial, indent=2))
else:
    final = snapshot(sys.argv[2])
    differences = {key: [value, final.get(key)] for key, value in initial.items()
                   if final.get(key) != value}
    print(json.dumps({'registers_checked': len(initial),
                      'match': not differences, 'differences': differences}, indent=2))
    sys.exit(bool(differences))
